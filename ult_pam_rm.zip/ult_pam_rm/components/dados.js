 export default DATA = [
    {
      id: '001',
      title: 'Camiseta do Corinthians 2024',
      desc: 'Camiseta Corinthians Treino Nike 2024 Academy Pro Masculina - Bege',
      desc1: 'Modelo torcedor',
      prec: 'R$279,99',
      img: require('./img/2.webp'),
      img2: require('./img/01.avif'),
    },
    
    {
      id: '002',
      title: 'Camiseta do Corinthians I 22/23',
      desc: 'Camisa Corinthians I 22/23 s/n° Torcedor Nike Masculina',
      desc1: 'Modelo torcedor',
      prec: 'R$323,00',
      img: require('./img/22.jpg'),
      img2: require('./img/002.jpg'),
    },
    {
      id: '003',
      title: 'Camiseta do Corinthians II 24/25',
      desc: 'Camisa Corinthians II 24/25 Torcedor Nike Masculina',
      desc1: 'Modelo torcedor',
      prec: 'R$379,99',
      img: require('./img/all.webp'),
      img2: require('./img/003.jpg'),
    },

    {
      id: '004',
      title: 'Camiseta do Corinthians II 20/21',
      desc: 'Camisa Corinthians II 20/21 Torcedor Nike Masculina',
      desc1: 'Modelo torcedor',
      prec: 'R$230,00',
      img: require('./img/bas.webp'),
      img2: require('./img/004.jpeg'),
    },
    {
      id: '005',
      title: 'Camiseta do Corinthians I 23/24',
      desc: 'Camisa Corinthians I 23/24 Torcedor Nike Masculina',
      desc1: 'Modelo torcedor',
      prec: 'R$329,90',
      img: require('./img/05.webp'),
      img2: require('./img/005.jpg'),
    },
    /*{
    img: require('./img/icon.png'),
    },*/

    
  ];
  